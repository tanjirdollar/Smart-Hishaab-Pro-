/**
 * 🔐 Google Account Authentication & OAuth Token Manager
 * Powered by Firebase Auth & Google Identity
 */
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut
} from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase App & Auth
export const firebaseApp = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(firebaseApp);

// Required OAuth Scopes for Google Account & Google Drive
export const SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/drive.file'
];

const provider = new GoogleAuthProvider();
SCOPES.forEach(scope => provider.addScope(scope));

// Primary Owner / Admin Email
export const DEFAULT_ADMIN_EMAIL = 'tanjir.dollar@gmail.com';

// In-memory token cache (synchronized with per-tab sessionStorage for session persistence)
let cachedAccessToken = null;
let currentGoogleUser = null;
let isSigningIn = false;

/**
 * Get list of authorized emails from localStorage or default
 */
export function getAuthorizedEmails() {
  try {
    const saved = localStorage.getItem('smart_hisab_allowed_emails');
    if (saved) {
      const list = JSON.parse(saved);
      if (Array.isArray(list) && list.length > 0) return list;
    }
  } catch (e) {
    console.warn('Failed to parse allowed emails', e);
  }
  return [DEFAULT_ADMIN_EMAIL];
}

/**
 * Save authorized email list
 */
export function saveAuthorizedEmails(emails) {
  try {
    localStorage.setItem('smart_hisab_allowed_emails', JSON.stringify(emails));
  } catch (e) {
    console.error('Failed to save allowed emails', e);
  }
}

/**
 * Check if given email is authorized
 */
export function isEmailAuthorized(email) {
  if (!email) return false;
  const clean = String(email).trim().toLowerCase();
  const allowed = getAuthorizedEmails().map(e => String(e).trim().toLowerCase());
  return allowed.includes(clean) || clean === DEFAULT_ADMIN_EMAIL.toLowerCase();
}

/**
 * Get in-memory / persistent OAuth Access Token
 */
export function getCachedAccessToken() {
  if (cachedAccessToken) return cachedAccessToken;
  try {
    const stored = localStorage.getItem('smart_hisab_google_access_token') || sessionStorage.getItem('smart_hisab_google_access_token');
    if (stored) {
      cachedAccessToken = stored;
      return stored;
    }
  } catch (e) {}
  return null;
}

export function setCachedAccessToken(token, userEmail = null) {
  cachedAccessToken = token;
  try {
    if (token) {
      localStorage.setItem('smart_hisab_google_access_token', token);
      localStorage.setItem('smart_hisab_google_token_time', Date.now().toString());
      localStorage.setItem('smart_hisab_drive_permanently_connected', 'true');
      sessionStorage.setItem('smart_hisab_google_access_token', token);
      // Persist across all browsers via backend server
      fetch('/api/drive-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: token, userEmail: userEmail || 'tanjir.dollar@gmail.com' })
      }).catch(() => {});
    } else {
      localStorage.removeItem('smart_hisab_google_access_token');
      localStorage.removeItem('smart_hisab_google_token_time');
      localStorage.removeItem('smart_hisab_drive_permanently_connected');
      sessionStorage.removeItem('smart_hisab_google_access_token');
      fetch('/api/drive-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken: null })
      }).catch(() => {});
    }
  } catch (e) {}
}

/**
 * Fetch persistent Google Drive token from server backend (enables other browsers to be connected without logging in)
 */
export async function fetchDriveTokenFromServer() {
  try {
    const res = await fetch('/api/drive-token');
    if (res.ok) {
      const data = await res.json();
      if (data && data.accessToken) {
        cachedAccessToken = data.accessToken;
        localStorage.setItem('smart_hisab_google_access_token', data.accessToken);
        localStorage.setItem('smart_hisab_drive_permanently_connected', 'true');
        return data.accessToken;
      }
    }
  } catch (e) {}
  return null;
}

/**
 * Check if Google Drive access token is actively available or permanently connected
 */
export function isDriveConnected() {
  const token = getCachedAccessToken();
  const isPerm = localStorage.getItem('smart_hisab_drive_permanently_connected') === 'true';
  const hasUser = Boolean(firebaseAuth.currentUser || getCurrentGoogleUser());
  return Boolean(token || (isPerm && hasUser) || isPerm);
}

/**
 * Explicit user-triggered Google Drive OAuth connect
 */
export async function connectGoogleDrive() {
  const res = await signInWithGoogle();
  return res?.accessToken || null;
}

/**
 * Get current authenticated user
 */
export function getCurrentGoogleUser() {
  return currentGoogleUser || firebaseAuth.currentUser;
}

/**
 * Initialize Google Auth State Listener
 */
export function initGoogleAuth(onUserAuthenticated, onUserUnauthenticated) {
  return onAuthStateChanged(firebaseAuth, async (user) => {
    if (user) {
      currentGoogleUser = user;
      const email = user.email || '';
      
      // Check authorization
      if (isEmailAuthorized(email)) {
        if (onUserAuthenticated) {
          onUserAuthenticated(user, getCachedAccessToken());
        }
      } else {
        console.warn('Unauthorized Google account attempted access:', email);
        await signOut(firebaseAuth);
        setCachedAccessToken(null);
        currentGoogleUser = null;
        if (onUserUnauthenticated) {
          onUserUnauthenticated('unauthorized_email', email);
        }
      }
    } else {
      currentGoogleUser = null;
      setCachedAccessToken(null);
      if (onUserUnauthenticated) {
        onUserUnauthenticated('signed_out');
      }
    }
  });
}

/**
 * Perform interactive Google Sign-In popup
 */
export async function signInWithGoogle() {
  if (isSigningIn) return null;
  isSigningIn = true;

  try {
    const result = await signInWithPopup(firebaseAuth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken || null;
    const user = result.user;

    if (!isEmailAuthorized(user.email)) {
      await signOut(firebaseAuth);
      setCachedAccessToken(null);
      currentGoogleUser = null;
      const err = new Error(`অননুমোদিত অ্যাকাউন্ট: ${user.email}। শুধুমাত্র অনুমোদিত অ্যাডমিন অ্যাকাউন্ট দিয়ে সাইন ইন করুন।`);
      err.code = 'UNAUTHORIZED_ACCOUNT';
      throw err;
    }

    if (token) {
      setCachedAccessToken(token, user.email);
    }
    currentGoogleUser = user;

    return { user, accessToken: getCachedAccessToken() };
  } catch (error) {
    console.error('Google Sign-In Error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
}

/**
 * Ensure an active OAuth Access Token exists for Drive operations
 * If interactive is false, it returns null instead of popping up an unauthorized dialog.
 */
export async function ensureAccessToken(interactive = false) {
  const existing = getCachedAccessToken();
  if (existing) return existing;
  if (!interactive) return null;
  const res = await signInWithGoogle();
  return res?.accessToken || null;
}

/**
 * Sign Out from Google Account
 */
export async function signOutFromGoogle() {
  try {
    await signOut(firebaseAuth);
    setCachedAccessToken(null);
    currentGoogleUser = null;
    sessionStorage.removeItem('smart_hisab_unlocked');
  } catch (err) {
    console.error('Google Sign-Out Error:', err);
    throw err;
  }
}
